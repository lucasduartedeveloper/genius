#pragma once

extern void load_lib_usb();
extern void init_lib_usb();
