﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ScpService")]
[assembly: AssemblyProduct("ScpService")]

[assembly: Guid("04b22521-cf98-4967-99a4-14479e672589")]
