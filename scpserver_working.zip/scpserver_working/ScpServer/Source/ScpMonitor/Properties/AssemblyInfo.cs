﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ScpMonitor")]
[assembly: AssemblyProduct("ScpMonitor")]

[assembly: Guid("85966027-b1d8-4a14-bc29-36f9091db86b")]
